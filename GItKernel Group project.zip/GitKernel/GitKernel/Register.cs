using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// This is the code for your desktop app.
// Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.

namespace GitKernel
{
    public partial class Register : Form
    {
        Classes.User user = new Classes.User();
        public Register()
        {
            InitializeComponent();
        }

        private void registerBtn_Click(object sender, EventArgs e)
        {
            bool taken = false;
            user.name = usernameBox.Text;
            user.password = passwordBox.Text;


            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc440;database=csc440_db;port=3306;password=Maroons18";
            MySqlConnection conn = new MySqlConnection(connStr);

            if (user.name != null && user.password != null && confirmBox.Text != "" && user.password == confirmBox.Text)
            {
                try
                {
                    conn.Open();

                    string sql = "SELECT * FROM user WHERE userName=@userNam";
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@userNam", user.name);
                    MySqlDataReader myReader = cmd.ExecuteReader();
                    if (myReader.Read()) //it's found a username that matches the one they chose
                    {
                        taken = true;
                        MessageBox.Show("The username you have chosen has already been taken. Choose another username and try again.", "Error: Username Taken");
                        myReader.Close();
                        conn.Close();
                    }
                    else //username hasn't been taken
                    {
                        myReader.Close();
                        conn.Close();
                        try
                        {
                            taken = false;
                            conn.Open();

                            cmd = new MySqlCommand("INSERT INTO user " +
                            "(userName, password, bio) " +
                            "VALUES(@username, @password, @bio)",
                            conn);

                            cmd.Parameters.AddWithValue("@username", usernameBox.Text);
                            cmd.Parameters.AddWithValue("@password", passwordBox.Text);
                            cmd.Parameters.AddWithValue("@bio", "");

                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        myReader.Close();
                        conn.Close();
                        MessageBox.Show("We have successfully recorded your user info. You may now log in.", "Success!");
                        this.Hide();
                        Login login = new Login();
                        login.Closed += (s, args) => this.Close();
                        login.Show();
                    }
                    
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            else
            {
                if (confirmBox.Text == "" || confirmBox.Text != user.password)
                {
                    MessageBox.Show("Your two passwords did not match. Try again.", "Error");
                }
                else
                {
                    MessageBox.Show("Please enter both a valid username and password.", "Error");
                }
            }
            
            // execute the query and return number of rows affected, should be one
            //   int RowsAffected = Cmd.ExecuteNonQuery();

            // close connection when done
            // Con.Close();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.Closed += (s, args) => this.Close();
            login.Show();
        }

        private void passwordBox_TextChanged(object sender, EventArgs e)
        {
           

        }
    }
}
