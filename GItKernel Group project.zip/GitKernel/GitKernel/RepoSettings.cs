﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GitKernel
{
    public partial class RepoSettings : Form
    {
        private MySqlConnection con;
        private MySqlCommand cmd;
        public RepoSettings()
        {
            InitializeComponent();
            repoLabel.Text = "Editing: "+Program.currentRepo.name;
            repoNameBox.Text = Program.currentRepo.name;
            repoDescriptionBox.Text = Program.currentRepo.description;
            gitUrlBox.Text = Program.currentRepo.repoUrl;
            fileUrlBox.Text = Program.currentRepo.fileUrl;
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.Closed += (s, args) => this.Close();
            login.Show();
        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserSettings f = new UserSettings();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private void repositoryBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main f = new Main();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private void savechanges_Click(object sender, EventArgs e)
        {
            String user = repoNameBox.Text;
            String gitURL = gitUrlBox.Text;
            String fileURL = fileUrlBox.Text;


            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc440;database=csc440_db;port=3306;password=Maroons18";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {

                conn.Open();

                string sql = "SELECT * FROM repository WHERE repoID=@repoID";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@repoID", Program.currentRepo.id);
                MySqlDataReader myReader = cmd.ExecuteReader();
                if (String.IsNullOrWhiteSpace(repoNameBox.Text) || String.IsNullOrWhiteSpace(gitUrlBox.Text)|| String.IsNullOrWhiteSpace(fileUrlBox.Text))
                {

                    MessageBox.Show("You must fill out the name, git URL, and file location of the repository", "error");
                }
                else
                {

                    String updatequery = "Update repository SET repoName=@repoName, repoDescription=@desc, repoURL=@repoURL, fileURL=@fileURL  where repoID=@repoID";
                    con = new MySqlConnection(connStr);
                    cmd = new MySqlCommand(updatequery, con);
                    // MySqlDataReader myReader;
                    con.Open();
                    cmd.Parameters.AddWithValue("@repoID", Program.currentUser.id);
                    cmd.Parameters.AddWithValue("@repoName", repoNameBox.Text);
                    cmd.Parameters.AddWithValue("@repoURL", gitUrlBox.Text);
                    cmd.Parameters.AddWithValue("@fileURL", fileUrlBox.Text);
                    cmd.Parameters.AddWithValue("@desc", repoDescriptionBox.Text);

                    cmd.ExecuteNonQuery();
                    Program.currentRepo.name = repoNameBox.Text;
                    Program.currentRepo.repoUrl = gitUrlBox.Text;
                    Program.currentRepo.fileUrl = fileUrlBox.Text;
                    Program.currentRepo.description = repoDescriptionBox.Text;

                    repoLabel.Text = "Editing: " + Program.currentRepo.name;

                    MessageBox.Show("Your repository has been updated");
                }
                myReader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();

        }

        private void browseBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {

                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    var filePath = folderBrowserDialog.SelectedPath;
                    fileUrlBox.Text = filePath;
                }

            }
          
        }
    }
}
