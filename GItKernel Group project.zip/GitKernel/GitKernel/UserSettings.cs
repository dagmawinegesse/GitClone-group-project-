﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GitKernel
{
    public partial class UserSettings : Form
    {

        private MySqlConnection con;
        private MySqlCommand cmd;
        public UserSettings()
        {
            InitializeComponent();
            newUsernameBox.Text = Program.currentUser.name;
            currPasswordBox.Text = Program.currentUser.password;
            newBio.Text = Program.currentUser.bio;
            newPasswordBox.Text = Program.currentUser.password;
        }

        private void UserSettings_Load(object sender, EventArgs e)
        {

        }

        private void savechanges_Click(object sender, EventArgs e)
        {
            String user= newUsernameBox.Text;
            String pass = newPasswordBox.Text;

            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc440;database=csc440_db;port=3306;password=Maroons18";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {

                conn.Open();

                string sql = "SELECT * FROM user WHERE userName=@userNam";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@userNam", newUsernameBox.Text);
                //cmd.Parameters.AddWithValue("@userPass",newPasswordBox);
                MySqlDataReader myReader = cmd.ExecuteReader();
                if (myReader.Read() && newUsernameBox.Text !=Program.currentUser.name)
                {
                    MessageBox.Show("Username has already been chosen","Error");
                } else if(currPasswordBox.Text!= Program.currentUser.password)
                {
                    MessageBox.Show("Please enter your current password","error");
                } else if(String.IsNullOrWhiteSpace(currPasswordBox.Text)|| String.IsNullOrWhiteSpace(newUsernameBox.Text))
                {

                    MessageBox.Show("Please enter a username and password", "error");
                }
                else
                {

                    String updatequery = "Update user SET userName=@newName , password=@newPass, bio=@newbio  where userID=@userID";
                    con = new MySqlConnection(connStr);
                    cmd = new MySqlCommand(updatequery, con);
                    // MySqlDataReader myReader;
                    con.Open();
                    cmd.Parameters.AddWithValue("@userID", Program.currentUser.id);
                    cmd.Parameters.AddWithValue("@newName", newUsernameBox.Text);
                    cmd.Parameters.AddWithValue("@newPass", newPasswordBox.Text);
                    cmd.Parameters.AddWithValue("@newbio", newBio.Text);

                    cmd.ExecuteNonQuery();
                    Program.currentUser.name = newUsernameBox.Text;
                    Program.currentUser.password = newPasswordBox.Text;
                    Program.currentUser.bio = newBio.Text;
                    MessageBox.Show("Your username and password have been edited");
                }
                myReader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            
        }

        private void repositoryBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main reg = new Main();
            reg.Closed += (s, args) => this.Close();
            reg.Show();
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.Closed += (s, args) => this.Close();
            login.Show();
        }
    }
}
