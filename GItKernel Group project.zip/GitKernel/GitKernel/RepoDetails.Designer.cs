﻿namespace GitKernel
{
    partial class RepoDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.logoutBtn = new System.Windows.Forms.Button();
            this.settingsBtn = new System.Windows.Forms.Button();
            this.repositoryBtn = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.repoTitleLabel = new System.Windows.Forms.Label();
            this.pullBtn = new System.Windows.Forms.Button();
            this.pushBtn = new System.Windows.Forms.Button();
            this.RepositorySetBtn = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.logoutBtn);
            this.panel2.Controls.Add(this.settingsBtn);
            this.panel2.Controls.Add(this.repositoryBtn);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(151, 466);
            this.panel2.TabIndex = 59;
            // 
            // logoutBtn
            // 
            this.logoutBtn.BackColor = System.Drawing.Color.Maroon;
            this.logoutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logoutBtn.ForeColor = System.Drawing.Color.PowderBlue;
            this.logoutBtn.Location = new System.Drawing.Point(35, 160);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(80, 23);
            this.logoutBtn.TabIndex = 2;
            this.logoutBtn.Text = "Logout";
            this.logoutBtn.UseVisualStyleBackColor = false;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click);
            // 
            // settingsBtn
            // 
            this.settingsBtn.BackColor = System.Drawing.Color.Maroon;
            this.settingsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.settingsBtn.ForeColor = System.Drawing.Color.PowderBlue;
            this.settingsBtn.Location = new System.Drawing.Point(35, 110);
            this.settingsBtn.Name = "settingsBtn";
            this.settingsBtn.Size = new System.Drawing.Size(80, 23);
            this.settingsBtn.TabIndex = 1;
            this.settingsBtn.Text = "Settings";
            this.settingsBtn.UseVisualStyleBackColor = false;
            this.settingsBtn.Click += new System.EventHandler(this.settingsBtn_Click);
            // 
            // repositoryBtn
            // 
            this.repositoryBtn.BackColor = System.Drawing.Color.Maroon;
            this.repositoryBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.repositoryBtn.ForeColor = System.Drawing.Color.PowderBlue;
            this.repositoryBtn.Location = new System.Drawing.Point(35, 60);
            this.repositoryBtn.Name = "repositoryBtn";
            this.repositoryBtn.Size = new System.Drawing.Size(80, 23);
            this.repositoryBtn.TabIndex = 0;
            this.repositoryBtn.Text = "Repositories";
            this.repositoryBtn.UseVisualStyleBackColor = false;
            this.repositoryBtn.Click += new System.EventHandler(this.repositoryBtn_Click);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Maroon;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.LightBlue;
            this.label10.Location = new System.Drawing.Point(267, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(216, 53);
            this.label10.TabIndex = 66;
            this.label10.Text = "GitKernel";
            // 
            // repoTitleLabel
            // 
            this.repoTitleLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.repoTitleLabel.AutoSize = true;
            this.repoTitleLabel.BackColor = System.Drawing.Color.Maroon;
            this.repoTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.repoTitleLabel.ForeColor = System.Drawing.Color.LightBlue;
            this.repoTitleLabel.Location = new System.Drawing.Point(270, 110);
            this.repoTitleLabel.Name = "repoTitleLabel";
            this.repoTitleLabel.Size = new System.Drawing.Size(138, 31);
            this.repoTitleLabel.TabIndex = 67;
            this.repoTitleLabel.Text = "Repo Title";
            // 
            // pullBtn
            // 
            this.pullBtn.BackColor = System.Drawing.Color.SteelBlue;
            this.pullBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pullBtn.ForeColor = System.Drawing.Color.LightBlue;
            this.pullBtn.Location = new System.Drawing.Point(220, 264);
            this.pullBtn.Name = "pullBtn";
            this.pullBtn.Size = new System.Drawing.Size(100, 53);
            this.pullBtn.TabIndex = 69;
            this.pullBtn.Text = "Pull";
            this.pullBtn.UseVisualStyleBackColor = false;
            this.pullBtn.Click += new System.EventHandler(this.pullBtn_Click);
            // 
            // pushBtn
            // 
            this.pushBtn.BackColor = System.Drawing.Color.SteelBlue;
            this.pushBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pushBtn.ForeColor = System.Drawing.Color.LightBlue;
            this.pushBtn.Location = new System.Drawing.Point(220, 180);
            this.pushBtn.Name = "pushBtn";
            this.pushBtn.Size = new System.Drawing.Size(100, 53);
            this.pushBtn.TabIndex = 70;
            this.pushBtn.Text = "Push";
            this.pushBtn.UseVisualStyleBackColor = false;
            this.pushBtn.Click += new System.EventHandler(this.pushBtn_Click);
            // 
            // RepositorySetBtn
            // 
            this.RepositorySetBtn.BackColor = System.Drawing.Color.SteelBlue;
            this.RepositorySetBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RepositorySetBtn.ForeColor = System.Drawing.Color.LightBlue;
            this.RepositorySetBtn.Location = new System.Drawing.Point(439, 180);
            this.RepositorySetBtn.Name = "RepositorySetBtn";
            this.RepositorySetBtn.Size = new System.Drawing.Size(100, 53);
            this.RepositorySetBtn.TabIndex = 71;
            this.RepositorySetBtn.Text = "Repository Settings";
            this.RepositorySetBtn.UseVisualStyleBackColor = false;
            this.RepositorySetBtn.Click += new System.EventHandler(this.RepositorySetBtn_Click);
            // 
            // RepoDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.RepositorySetBtn);
            this.Controls.Add(this.pushBtn);
            this.Controls.Add(this.pullBtn);
            this.Controls.Add(this.repoTitleLabel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "RepoDetails";
            this.Text = "RepoDetails";
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button logoutBtn;
        private System.Windows.Forms.Button settingsBtn;
        private System.Windows.Forms.Button repositoryBtn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label repoTitleLabel;
        private System.Windows.Forms.Button pullBtn;
        private System.Windows.Forms.Button pushBtn;
        private System.Windows.Forms.Button RepositorySetBtn;
    }
}