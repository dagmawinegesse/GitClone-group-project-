﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GitKernel
{
    public partial class Login : Form
    {

        public Login()
        {
            InitializeComponent();
            Program.currentUser = new Classes.User();
            Program.currentRepo = new Classes.Repository();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
           
            Program.currentUser.name = usernameBox.Text;
            Program.currentUser.password = passwordBox.Text;

            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc440;database=csc440_db;port=3306;password=Maroons18";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {

                conn.Open();
                
                string sql = "SELECT * FROM user WHERE userName=@userNam AND password=@userPass";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@userNam", Program.currentUser.name);
                cmd.Parameters.AddWithValue("@userPass", Program.currentUser.password);
                MySqlDataReader myReader = cmd.ExecuteReader();
                if (myReader.Read())
                {
                    Program.currentUser.id = int.Parse(myReader["userID"].ToString());
                    Program.currentUser.repositories = new List<Classes.Repository>();
                    Program.currentUser.name = myReader["userName"].ToString();
                    Program.currentUser.password = myReader["password"].ToString();
                    Program.currentUser.bio = myReader["bio"].ToString();

                    this.Hide();
                    Main main = new Main();
                    main.Closed += (s, args) => this.Close();
                    main.Show();
                    
                }
                else
                {
                    MessageBox.Show("Please enter a valid username and password.", "Error: Incorrect Information");
                }
                myReader.Close();
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
        }

        private void registerBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Register reg = new Register();
            reg.Closed += (s, args) => this.Close();
            reg.Show();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
