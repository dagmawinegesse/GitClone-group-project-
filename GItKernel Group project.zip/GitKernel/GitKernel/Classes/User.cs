﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace GitKernel.Classes
{
    class User
    {
        public int id { get; set; }
        public String name { get; set; }
        public String password { get; set; }
        public String bio { get; set; }
        public int count { get; set; }
        public List<Repository> repositories = new List<Repository>();

        public User()
        {

        }

        public User(int id, String name, String password, String bio, List<Repository> repositories)
        {
            this.id = id;
            this.name = name;
            this.password = password;
            this.bio = bio;
            this.repositories = repositories;
        }
        public static void createRepoList()
        {
            //prepare an SQL query to retrieve all the events on the same, specified date
            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc440;database=csc440_db;port=3306;password=Maroons18";
            MySqlConnection conn = new MySqlConnection(connStr);
            Program.currentUser.repositories.Clear();
            try
            {
                Repository repo = new Repository();
                conn.Open();
                
                string sql = "SELECT * FROM user_connections WHERE userID=@userID";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@userID", Program.currentUser.id);
                MySqlDataReader myReader = cmd.ExecuteReader();
                while (myReader.Read())
                {
                    repo = new Repository();
                    repo.id = int.Parse(myReader["repoID"].ToString());
                    Program.currentUser.repositories.Add(repo);
                }
                myReader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();

            getRepoInfo();

        }
        private static void getRepoInfo()
        {
            //prepare an SQL query to retrieve all the events on the same, specified date
            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc440;database=csc440_db;port=3306;password=Maroons18";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Repository repo = new Repository();
                conn.Open();
                for (int i = 0; i < Program.currentUser.count; i++)
                {
                    //selecting computer number i in lab
                    string sql = "SELECT * FROM repository WHERE repoID=@repoID";
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@repoID", Program.currentUser.repositories[i].id);
                    MySqlDataReader myReader = cmd.ExecuteReader();
                    if (myReader.Read())
                    {
                        Program.currentUser.repositories[i] = new Repository(int.Parse(myReader["repoID"].ToString()),
                            myReader["repoName"].ToString(), myReader["repoDescription"].ToString(), myReader["repoURL"].ToString(),
                            myReader["fileURL"].ToString());
                    }
                    myReader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
        }
    }
}
