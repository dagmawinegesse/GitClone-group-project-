﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GitKernel
{
    public partial class repoListItem : UserControl
    {
        public repoListItem()
        {
            InitializeComponent();
        }

        #region Properties

        private int _id;
        private String _name;
        private String _description;
        private String _gitUrl;
        private String _fileUrl;

        [Category("Custom Props")]
        public int id
        {
            get { return _id; }
            set { _id = value; }
        }
        [Category("Custom Props")]
        public String name
        {
            get { return _name; }
            set { _name = value; repoNameLabel.Text = value; }
        }
        [Category("Custom Props")]
        public String description
        {
            get { return _description; }
            set { _description = value; descBox.Text = value; }
        }
        [Category("Custom Props")]
        public String gitUrl
        {
            get { return _gitUrl; }
            set { _gitUrl = value; gitUrlLabel.Text = value; }
        }
        [Category("Custom Props")]
        public String fileUrl
        {
            get { return _fileUrl; }
            set { _fileUrl = value; fileUrlLabel.Text = value; }
        }


        #endregion

        private void repoBtnClick(object sender, EventArgs e)
        {
            Program.currentRepo.id = id;
            var parent = ((repoListItem)sender).Parent.FindForm();
            RepoDetails f = new RepoDetails();
            parent.Hide();
            f.Closed += (s, args) => parent.Close();
            f.Show();
            parent.Dispose();
        }
    }
}
