﻿namespace GitKernel
{
    partial class repoListItem
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.repoNameLabel = new System.Windows.Forms.Label();
            this.gitUrlLabel = new System.Windows.Forms.Label();
            this.descBox = new System.Windows.Forms.TextBox();
            this.fileUrlLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // repoNameLabel
            // 
            this.repoNameLabel.AutoSize = true;
            this.repoNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.repoNameLabel.ForeColor = System.Drawing.Color.LightBlue;
            this.repoNameLabel.Location = new System.Drawing.Point(15, 10);
            this.repoNameLabel.Name = "repoNameLabel";
            this.repoNameLabel.Size = new System.Drawing.Size(109, 17);
            this.repoNameLabel.TabIndex = 0;
            this.repoNameLabel.Text = "repoNameLabel";
            // 
            // gitUrlLabel
            // 
            this.gitUrlLabel.AutoSize = true;
            this.gitUrlLabel.BackColor = System.Drawing.Color.SteelBlue;
            this.gitUrlLabel.ForeColor = System.Drawing.Color.LightBlue;
            this.gitUrlLabel.Location = new System.Drawing.Point(104, 65);
            this.gitUrlLabel.Name = "gitUrlLabel";
            this.gitUrlLabel.Size = new System.Drawing.Size(57, 13);
            this.gitUrlLabel.TabIndex = 1;
            this.gitUrlLabel.Text = "gitUrlLabel";
            // 
            // descBox
            // 
            this.descBox.BackColor = System.Drawing.Color.SteelBlue;
            this.descBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.descBox.Location = new System.Drawing.Point(168, 26);
            this.descBox.Multiline = true;
            this.descBox.Name = "descBox";
            this.descBox.Size = new System.Drawing.Size(250, 32);
            this.descBox.TabIndex = 2;
            // 
            // fileUrlLabel
            // 
            this.fileUrlLabel.AutoSize = true;
            this.fileUrlLabel.ForeColor = System.Drawing.Color.LightBlue;
            this.fileUrlLabel.Location = new System.Drawing.Point(104, 82);
            this.fileUrlLabel.Name = "fileUrlLabel";
            this.fileUrlLabel.Size = new System.Drawing.Size(59, 13);
            this.fileUrlLabel.TabIndex = 3;
            this.fileUrlLabel.Text = "fileUrlLabel";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SteelBlue;
            this.label1.ForeColor = System.Drawing.Color.LightBlue;
            this.label1.Location = new System.Drawing.Point(165, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Description";
            // 
            // repoListItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fileUrlLabel);
            this.Controls.Add(this.descBox);
            this.Controls.Add(this.gitUrlLabel);
            this.Controls.Add(this.repoNameLabel);
            this.Margin = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.Name = "repoListItem";
            this.Size = new System.Drawing.Size(460, 100);
            this.Click += new System.EventHandler(this.repoBtnClick);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label repoNameLabel;
        private System.Windows.Forms.Label gitUrlLabel;
        private System.Windows.Forms.TextBox descBox;
        private System.Windows.Forms.Label fileUrlLabel;
        private System.Windows.Forms.Label label1;
    }
}
