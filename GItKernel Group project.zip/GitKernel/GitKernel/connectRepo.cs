﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GitKernel
{
    public partial class connectRepo : Form
    {
        private MySqlConnection con;
        private MySqlCommand cmd;
        public connectRepo()
        {
            InitializeComponent();
            repoNameBox.Text = Program.currentRepo.name;
            repoDescriptionBox.Text = Program.currentRepo.description;
            gitUrlBox.Text = Program.currentRepo.repoUrl;
            fileUrlBox.Text = Program.currentRepo.fileUrl;
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.Closed += (s, args) => this.Close();
            login.Show();
        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserSettings f = new UserSettings();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private void repositoryBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main f = new Main();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private void savechanges_Click(object sender, EventArgs e)
        {

            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc440;database=csc440_db;port=3306;password=Maroons18";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {

                conn.Open();

                string sql = "INSERT INTO repository " +
                           "(repoName, repoDescription, repoURL, fileURL) " +
                           "VALUES(@repoName, @repoDescription, @repoURL, @fileUrl);" +
                           "SELECT LAST_INSERT_ID();";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@repoName", repoNameBox.Text);
                cmd.Parameters.AddWithValue("@repoURL", gitUrlBox.Text);
                cmd.Parameters.AddWithValue("@fileURL", fileUrlBox.Text);
                cmd.Parameters.AddWithValue("@repoDescription", repoDescriptionBox.Text);

                if (String.IsNullOrWhiteSpace(repoNameBox.Text) || String.IsNullOrWhiteSpace(gitUrlBox.Text) || String.IsNullOrWhiteSpace(fileUrlBox.Text))
                {
                    MessageBox.Show("You must fill out the name, git URL, and file location of the repository", "error");
                }
                else
                {

                    //r result = cmd.ExecuteScalar();
                    Program.currentRepo.id = Convert.ToInt32(cmd.ExecuteScalar());

                    Program.currentRepo.name = repoNameBox.Text;
                    Program.currentRepo.repoUrl = gitUrlBox.Text;
                    Program.currentRepo.fileUrl = fileUrlBox.Text;
                    Program.currentRepo.description = repoDescriptionBox.Text;

                    MessageBox.Show("Your repository has been added");
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                conn.Close();
            }

            try
            {

                conn.Open();

                string sql = "INSERT INTO user_connections " +
                           "(userID, repoID) " +
                           "VALUES(@userID, @repoID);";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@userID", Program.currentUser.id);
                cmd.Parameters.AddWithValue("@repoID", Program.currentRepo.id);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            this.Hide();
            Main f = new Main();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private void browseBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {

                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    var filePath = folderBrowserDialog.SelectedPath;
                    fileUrlBox.Text = filePath;
                }

            }

        }
    }
}
