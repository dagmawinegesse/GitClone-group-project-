﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GitKernel
{
    public partial class RepoDetails : Form
    {
        public RepoDetails()
        {
            InitializeComponent();
            loadRepo();
        }

        private void loadRepo()
        {
            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc440;database=csc440_db;port=3306;password=Maroons18";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                conn.Open();

                string sql = "SELECT * FROM repository WHERE repoID=@repoID";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@repoID", Program.currentRepo.id);
                MySqlDataReader myReader = cmd.ExecuteReader();
                if (myReader.Read())
                {
                    Program.currentRepo.id = int.Parse(myReader["repoID"].ToString());
                    Program.currentRepo.name = myReader["repoName"].ToString();
                    Program.currentRepo.description = myReader["repoDescription"].ToString();
                    Program.currentRepo.repoUrl = myReader["repoURL"].ToString();
                    Program.currentRepo.fileUrl = myReader["fileURL"].ToString();
                }
                myReader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();

            repoTitleLabel.Text = Program.currentRepo.name;

        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.Closed += (s, args) => this.Close();
            login.Show();
        }

        private void RepositorySetBtn_Click(object sender, EventArgs e)
        {
            RepoSettings US = new RepoSettings(); // 
            US.Show();
            RepoDetails L = new RepoDetails(); //
            this.Hide();

        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserSettings f = new UserSettings();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private void repositoryBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main f = new Main();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private bool RunCommands(IEnumerable<string> commands)
        {
            try
            {

                Process p = new Process();
                ProcessStartInfo info = new ProcessStartInfo();
                info.FileName = "cmd.exe";
                info.RedirectStandardInput = true;
                info.UseShellExecute = false;

                p.StartInfo = info;
                p.Start();

                using (StreamWriter sw = p.StandardInput)
                {
                    if (sw.BaseStream.CanWrite)
                    {
                        foreach (var command in commands)
                        {
                            sw.WriteLine(command);
                        }
                    }
                }
            }
            catch(Exception)
            {
                return false;
            }
            return true;
        }

        private void pushBtn_Click(object sender, EventArgs e)
        {
            if (Directory.Exists(Program.currentRepo.fileUrl)) {//they have files
                string isGitThere = Program.currentRepo.fileUrl+@"\.git";

                var commands = new List<string>();
                commands.Add($"pushd {Program.currentRepo.fileUrl}");

                if (!Directory.Exists(isGitThere))
                {
                    commands.Add("git init");
                }
                commands.Add("git add -A");
                commands.Add("git commit -m \"GitKernel Commit\"");
                commands.Add($"git remote add GitKernelRemote {Program.currentRepo.repoUrl}");
                commands.Add($"git remote set-url GitKernelRemote {Program.currentRepo.repoUrl}");
                commands.Add("git push GitKernelRemote master");

                if(RunCommands(commands))
                { 
                    MessageBox.Show("You have pushed your files to your git repository.", "Success");
                }
                else
                {
                    MessageBox.Show("Please be sure you have the correct git url and try again.", "Error: incorrect git URL");
                }
            }
            else
            {
                MessageBox.Show(Program.currentRepo.fileUrl);
                MessageBox.Show("Your desired file location does not exist, please choose a valid location", "Error: Invalid File Location");
            }
        }

        private void pullBtn_Click(object sender, EventArgs e)
        {
            if (Directory.Exists(Program.currentRepo.fileUrl))
            {//they have files
                string isGitThere = Program.currentRepo.fileUrl + @"\.git";

                var commands = new List<string>();
                commands.Add($"pushd {Program.currentRepo.fileUrl}");

                if (!Directory.Exists(isGitThere))
                {
                    commands.Add($"git clone {Program.currentRepo.fileUrl}");
                }
                else { 
                    commands.Add($"git remote add GitKernelRemote {Program.currentRepo.repoUrl}");
                    commands.Add($"git remote set-url GitKernelRemote {Program.currentRepo.repoUrl}");
                    commands.Add("git pull GitKernelRemote master");
                }
                if (RunCommands(commands))
                {
                    MessageBox.Show("You have pulled your files from your git repository.", "Success");
                }
                else
                {
                    MessageBox.Show("Please be sure you have the correct git url and try again.", "Error: incorrect git URL");
                }
            }
            else
            {
                MessageBox.Show(Program.currentRepo.fileUrl);
                MessageBox.Show("Your desired file location does not exist, please choose a valid location", "Error: Invalid File Location");
            }
        }
    }
}
