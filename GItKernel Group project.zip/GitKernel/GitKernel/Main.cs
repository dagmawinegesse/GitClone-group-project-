﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GitKernel
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void listRepos()
        {

            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc440;database=csc440_db;port=3306;password=Maroons18";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {

                conn.Open();

                string sql = "SELECT COUNT(*) FROM user_connections WHERE userID=@ID";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ID", Program.currentUser.id);

                Program.currentUser.count = Convert.ToInt32(cmd.ExecuteScalar());


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();

            if (Program.currentUser.count > 0)
            {
                Classes.User.createRepoList();
            }

            repositoryPanel.Controls.Clear();

            repoListItem[] repoListItems = new repoListItem[Program.currentUser.repositories.Count()];
            for (int i = 0; i < Program.currentUser.repositories.Count(); i++)
            {
                repoListItems[i] = new repoListItem();
                repoListItems[i].id = Program.currentUser.repositories[i].id;
                repoListItems[i].name = Program.currentUser.repositories[i].name;
                repoListItems[i].description = Program.currentUser.repositories[i].description;
                repoListItems[i].gitUrl = Program.currentUser.repositories[i].repoUrl;
                repoListItems[i].fileUrl = Program.currentUser.repositories[i].fileUrl;

                repositoryPanel.Controls.Add(repoListItems[i]);
            }
        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserSettings reg = new UserSettings();
            reg.Closed += (s, args) => this.Close();
            reg.Show();
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            Program.currentUser = new Classes.User();
            this.Hide();
            Login login = new Login();
            login.Closed += (s, args) => this.Close();
            login.Show();
        }

        private void connectNewRepoBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            connectRepo f = new connectRepo();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private void Main_Shown(object sender, EventArgs e)
        {
            listRepos();
        }
    }
}
