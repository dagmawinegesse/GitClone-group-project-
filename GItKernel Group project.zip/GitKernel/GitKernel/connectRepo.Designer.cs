﻿namespace GitKernel
{
    partial class connectRepo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.browseBtn = new System.Windows.Forms.Button();
            this.fileUrlBox = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.logoutBtn = new System.Windows.Forms.Button();
            this.settingsBtn = new System.Windows.Forms.Button();
            this.repositoryBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.repoDescriptionBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.repoLabel = new System.Windows.Forms.Label();
            this.savechanges = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gitUrlBox = new System.Windows.Forms.TextBox();
            this.repoNameBox = new System.Windows.Forms.TextBox();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // browseBtn
            // 
            this.browseBtn.BackColor = System.Drawing.Color.SteelBlue;
            this.browseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.browseBtn.ForeColor = System.Drawing.Color.LightBlue;
            this.browseBtn.Location = new System.Drawing.Point(575, 281);
            this.browseBtn.Name = "browseBtn";
            this.browseBtn.Size = new System.Drawing.Size(89, 28);
            this.browseBtn.TabIndex = 85;
            this.browseBtn.Text = "Browse";
            this.browseBtn.UseVisualStyleBackColor = false;
            this.browseBtn.Click += new System.EventHandler(this.browseBtn_Click);
            // 
            // fileUrlBox
            // 
            this.fileUrlBox.Location = new System.Drawing.Point(371, 255);
            this.fileUrlBox.Name = "fileUrlBox";
            this.fileUrlBox.Size = new System.Drawing.Size(293, 20);
            this.fileUrlBox.TabIndex = 84;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.logoutBtn);
            this.panel2.Controls.Add(this.settingsBtn);
            this.panel2.Controls.Add(this.repositoryBtn);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(141, 474);
            this.panel2.TabIndex = 83;
            // 
            // logoutBtn
            // 
            this.logoutBtn.BackColor = System.Drawing.Color.Maroon;
            this.logoutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logoutBtn.ForeColor = System.Drawing.Color.PowderBlue;
            this.logoutBtn.Location = new System.Drawing.Point(35, 160);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(80, 23);
            this.logoutBtn.TabIndex = 2;
            this.logoutBtn.Text = "Logout";
            this.logoutBtn.UseVisualStyleBackColor = false;
            // 
            // settingsBtn
            // 
            this.settingsBtn.BackColor = System.Drawing.Color.Maroon;
            this.settingsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.settingsBtn.ForeColor = System.Drawing.Color.PowderBlue;
            this.settingsBtn.Location = new System.Drawing.Point(35, 110);
            this.settingsBtn.Name = "settingsBtn";
            this.settingsBtn.Size = new System.Drawing.Size(80, 23);
            this.settingsBtn.TabIndex = 1;
            this.settingsBtn.Text = "Settings";
            this.settingsBtn.UseVisualStyleBackColor = false;
            // 
            // repositoryBtn
            // 
            this.repositoryBtn.BackColor = System.Drawing.Color.Maroon;
            this.repositoryBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.repositoryBtn.ForeColor = System.Drawing.Color.PowderBlue;
            this.repositoryBtn.Location = new System.Drawing.Point(35, 60);
            this.repositoryBtn.Name = "repositoryBtn";
            this.repositoryBtn.Size = new System.Drawing.Size(80, 23);
            this.repositoryBtn.TabIndex = 0;
            this.repositoryBtn.Text = "Repositories";
            this.repositoryBtn.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.BackColor = System.Drawing.Color.Maroon;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label4.Location = new System.Drawing.Point(248, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 21);
            this.label4.TabIndex = 82;
            this.label4.Text = "Description";
            // 
            // repoDescriptionBox
            // 
            this.repoDescriptionBox.Location = new System.Drawing.Point(371, 138);
            this.repoDescriptionBox.Multiline = true;
            this.repoDescriptionBox.Name = "repoDescriptionBox";
            this.repoDescriptionBox.Size = new System.Drawing.Size(293, 85);
            this.repoDescriptionBox.TabIndex = 81;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Maroon;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(248, 256);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 17);
            this.label3.TabIndex = 80;
            this.label3.Text = "File Location";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Maroon;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.LightBlue;
            this.label10.Location = new System.Drawing.Point(387, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(216, 53);
            this.label10.TabIndex = 79;
            this.label10.Text = "GitKernel";
            // 
            // repoLabel
            // 
            this.repoLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.repoLabel.BackColor = System.Drawing.Color.Maroon;
            this.repoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.repoLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.repoLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.repoLabel.Location = new System.Drawing.Point(246, 61);
            this.repoLabel.Name = "repoLabel";
            this.repoLabel.Size = new System.Drawing.Size(497, 34);
            this.repoLabel.TabIndex = 78;
            this.repoLabel.Text = "Add Repository Info";
            // 
            // savechanges
            // 
            this.savechanges.BackColor = System.Drawing.Color.SteelBlue;
            this.savechanges.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savechanges.ForeColor = System.Drawing.Color.LightBlue;
            this.savechanges.Location = new System.Drawing.Point(432, 322);
            this.savechanges.Name = "savechanges";
            this.savechanges.Size = new System.Drawing.Size(100, 53);
            this.savechanges.TabIndex = 77;
            this.savechanges.Text = "Save Changes";
            this.savechanges.UseVisualStyleBackColor = false;
            this.savechanges.Click += new System.EventHandler(this.savechanges_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Maroon;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(248, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 17);
            this.label2.TabIndex = 76;
            this.label2.Text = "Repository Name";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.BackColor = System.Drawing.Color.Maroon;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Location = new System.Drawing.Point(248, 228);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 21);
            this.label1.TabIndex = 75;
            this.label1.Text = "git URL";
            // 
            // gitUrlBox
            // 
            this.gitUrlBox.Location = new System.Drawing.Point(371, 229);
            this.gitUrlBox.Name = "gitUrlBox";
            this.gitUrlBox.Size = new System.Drawing.Size(293, 20);
            this.gitUrlBox.TabIndex = 74;
            // 
            // repoNameBox
            // 
            this.repoNameBox.Location = new System.Drawing.Point(371, 111);
            this.repoNameBox.Name = "repoNameBox";
            this.repoNameBox.Size = new System.Drawing.Size(150, 20);
            this.repoNameBox.TabIndex = 73;
            // 
            // connectRepo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.browseBtn);
            this.Controls.Add(this.fileUrlBox);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.repoDescriptionBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.repoLabel);
            this.Controls.Add(this.savechanges);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gitUrlBox);
            this.Controls.Add(this.repoNameBox);
            this.Name = "connectRepo";
            this.Text = "Connect New Repository";
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button browseBtn;
        private System.Windows.Forms.TextBox fileUrlBox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button logoutBtn;
        private System.Windows.Forms.Button settingsBtn;
        private System.Windows.Forms.Button repositoryBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox repoDescriptionBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label repoLabel;
        private System.Windows.Forms.Button savechanges;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox gitUrlBox;
        private System.Windows.Forms.TextBox repoNameBox;
    }
}